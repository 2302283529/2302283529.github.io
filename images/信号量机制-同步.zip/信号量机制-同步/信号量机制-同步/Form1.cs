﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 信号量机制_同步
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 启动线程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        AutoResetEvent autoResetEvent = new AutoResetEvent(false);
        //ManualResetEvent autoResetEvent = new ManualResetEvent(false);
        private void button1_Click(object sender, EventArgs e)
        {
            //当你碰到“System.InvalidOperationException:“线程间操作无效: 从不是创建控件“label1”的线程访问它。”这个错误的时候请加上
            CheckForIllegalCrossThreadCalls = false;
            //StartThread1();
            //StartThread2();
            #region 信号机制的工作原理
            ////实例化线程
            //Thread Work = new Thread(()=> {
            //    //启动线程
            //    label1.Text = "线程启动..." + Environment.NewLine;
            //    label1.Text += "开始处理一些实际的工作" + Environment.NewLine;
            //    #region 业务逻辑代码
            //    //工作逻辑略
            //    #endregion
            //    label1.Text += "我开始等待别的线程给我信号，才愿意继续下去"+Environment.NewLine;
            //    //让线程进入等待(阻塞线程)
            //    autoResetEvent.WaitOne();
            //    label1.Text += "我继续做一些工作，然后结束了！";
            //    #region 业务逻辑代码
            //    //工作逻辑略
            //    #endregion

            //});
            //前台进程还是后台进程，true 后台，反之
            //Work.IsBackground = true;
            ////启动线程
            //Work.Start();
            #endregion

            #region 信号机制实例
            Thread Client = new Thread(()=> {
                while (true)
                {
                    //等10秒，10秒没有信号，显示断开
                    //有信号，则显示更新
                    bool re = autoResetEvent.WaitOne(10000);
                    if (re)
                    {
                        label1.Text = string.Format("时间：{0}，{1}", DateTime.Now.ToString(), "保持连接状态");
                    }
                    else {

                        label1.Text = string.Format("时间：{0}，{1}", DateTime.Now.ToString(), "断开，需要重启");
                    }
                }

            });
            //设置为后台线程
            Client.IsBackground = true;
            //启动线程，开始你的表演
            Client.Start();
            #endregion
        }
        //第一个线程
        private void StartThread1()
        {
            Thread work1 = new Thread(()=>{
                this.label1.Text = "线程1启动..."+Environment.NewLine;
                this.label1.Text += "开始处理一些实际的工作..." + Environment.NewLine;
                #region 业务逻辑代码
                //工作逻辑略
                #endregion
                //让线程进入等待(阻塞线程)
                autoResetEvent.WaitOne();
                this.label1.Text += "我需要继续做一些工作，然后结束了！";
            });
            //前台进程还是后台进程，true 后台，反之
            work1.IsBackground = true;
            ////启动线程
            work1.Start();
        }
        //第二个线程
        private void StartThread2()
        {
            Thread work2 = new Thread(() => {
                this.label2.Text = "线程2启动..." + Environment.NewLine;
                this.label2.Text += "开始处理一些实际的工作..." + Environment.NewLine;
                #region 业务逻辑代码
                //工作逻辑略
                #endregion
                //让线程进入等待(阻塞线程)
                autoResetEvent.WaitOne();
                this.label2.Text += "我需要继续做一些工作，然后结束了！";
            });
            //前台进程还是后台进程，true 后台，反之
            work2.IsBackground = true;
            ////启动线程
            work2.Start();
        }

        /// <summary>
        /// 给线程一个信号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            //给在autoResetEvent上等待的线程一个信号
            autoResetEvent.Set();
        }
    }
}
