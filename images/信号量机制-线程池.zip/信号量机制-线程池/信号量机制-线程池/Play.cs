﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    /// <summary>
    /// 攻击类
    /// </summary>
    internal class Play
    {
        /// <summary>
        /// 攻击者名字
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 攻击力
        /// </summary>
        public int power { get; set; }

        /// <summary>
        /// 法术攻击
        /// </summary>
        public void magicExecute(object monster)
        {
            //实例化怪物类
            Monster m = monster as Monster;
            //在指定对象上获取排它锁
            Monitor.Enter(monster);
            //判断当前怪物的血量  >0 表示还活这。
            while (m.Blood>0)
            {
                //Wait(object)方法：释放对象上的锁并阻止当前线程，直到它重新获取该锁，该线程进入等待队列。
                // 释放对象上的锁并阻止当前线程，直到它重新获取该锁。
                Monitor.Wait(monster);

                Console.WriteLine("当前英雄:{0},正在使用法术攻击怪物",this.Name);
                //当前的血量大于当前的攻击力
                if (m.Blood >= power)
                {
                    m.Blood -= power;
                }
                else {
                    m.Blood = 0;
                }
                Thread.Sleep(300);
                Console.WriteLine("怪物的血量还剩下{0}",m.Blood);
                // Pulse方法：只有锁的当前所有者可以使用 Pulse 向等待对象发出信号，当前拥有指定对象上的锁的线程调用此方法以便向队列中的下一个线程发出锁的信号。接收到脉冲后，等待线程就被移动到就绪队列中。在调用 Pulse 的线程释放锁后，就绪队列中的下一个线程（不一定是接收到脉冲的线程）将获得该锁。
                //另外： Wait 和 Pulse 方法必须写在 Monitor.Enter 和Moniter.Exit 之间。
                //通知所有的等待线程对象状态的更改。
                Monitor.PulseAll(monster);
            }
            //释放指定对象上的排它锁
            Monitor.Exit(monster);
        }
        
        /// <summary>
        /// 物理攻击
        /// </summary>
        public void physicsExecute(object monster)
        {
            //实例化怪物类
            Monster m = monster as Monster;
            //在指定对象上获取排它锁
            Monitor.Enter(monster);
            //判断当前怪物的血量
            while (m.Blood>0)
            {
                // Pulse方法：只有锁的当前所有者可以使用 Pulse 向等待对象发出信号，当前拥有指定对象上的锁的线程调用此方法以便向队列中的下一个线程发出锁的信号。接收到脉冲后，等待线程就被移动到就绪队列中。在调用 Pulse 的线程释放锁后，就绪队列中的下一个线程（不一定是接收到脉冲的线程）将获得该锁。
                //另外： Wait 和 Pulse 方法必须写在 Monitor.Enter 和Moniter.Exit 之间。
                Monitor.PulseAll(monster);
                //thread_second将自己流放到等待队列并释放自身对同步锁的独占，该等待设置了1S的超时
                // 值，当B线程在1S之内没有再次获取到锁自动添加到就绪队列。
                if (Monitor.Wait(monster,1000))  //非常关键的一句代码
                {
                    Console.WriteLine("当前英雄:{0},正在使用物理攻击力打击怪物",this.Name);
                    //判断怪物收到攻击时是否存活
                    if (m.Blood >= power)
                    {
                        m.Blood -= power;
                    }
                    else
                    {
                        m.Blood = 0;
                    }
                    Thread.Sleep(300);
                    Console.WriteLine("怪物的血量还剩下{0}",m.Blood);
                }
            }
            //释放指定对象桑的排他锁
            Monitor.Exit(monster);
        }

    }
}
