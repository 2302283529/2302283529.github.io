﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    /// <summary>
    /// 下面的代码中有三个线程，threadA,threadB和主线程，threadA优先级最高，threadB优先级最低。这一点从运行结果中也可以看出，线程B 偶尔会出现在主线程和线程A前面。当有多个线程同时处于可执行状态，系统优先执行优先级较高的线程，但这只意味着优先级较高的线程占有更多的CPU时间，并不意味着一定要先执行完优先级较高的线程，才会执行优先级较低的线程。
    /// </summary>
    public class Threadpriority
    {
        public void Manin()
        {
            Thread threadA = new Thread(THreadMethod); //执行的必须是无返回值的方法
            threadA.Name = "小A"; //未当前的线程取一个名字

            Thread threadB = new Thread(THreadMethod); //执行的必须是无返回值的方法
            threadB.Name = "小B"; //未当前的线程取一个名字

            threadA.Priority = ThreadPriority.Highest;//高于主线程的优先级
            threadB.Priority = ThreadPriority.BelowNormal;//低于主线程的优先级

            threadA.Start();//开启线程
            threadB.Start();//开启线程

            Thread.CurrentThread.Name = "C";
            THreadMethod(new object());
        }
        private static void THreadMethod(object parameter)//方法内可以有参数，也可以没有参数
        {

            for (int i = 0; i < 10; i++)
            {
                //Console.Write(Thread.CurrentThread.Name);
                Console.WriteLine("我是:{0},我循环{1}次", Thread.CurrentThread.Name, i);
            }
        }
    }
}
