﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    class Program
    {
      
        //我们的控制台程序入口是main函数，它所在的线程即是主线程
        static void Main(string[] args)
        {
            #region 线程的相关属性
            //Start start = new Start();  //实例话一个类，也就是一个对象   
            //start.Manin();              //调用里面的方法或者属性
            #endregion；

            #region 线程的Abort方法的使用
            //Abort Ab = new Abort();
            //Ab.Manin();
            #endregion

            #region 线程的ResetAbort方法的使用
            //ResetAbort Reset = new ResetAbort();
            //Reset.Manin();
            #endregion

            #region 线程的Sleep方法的使用
            //Sleep Sl = new Sleep();
            //Sl.Manin();
            #endregion

            #region 线程的join方法的使用
            //join jo = new join();
            //jo.Manin();
            #endregion

            #region 线程的挂起/回复的使用
            //Suspent Su = new Suspent();
            //Su.Manin();
            #endregion

            #region 线程的优先级使用
            //Threadpriority Th = new Threadpriority();
            //Th.Manin();
            #endregion

            #region 线程同步
            //@lock lk= new @lock();
            //lk.Manin();
            #endregion

            #region 小游戏
            ////怪物类/血量1000
            //Monster monster = new Monster(1000);
            ////物理攻击类
            //Play play1 = new Play() { Name = "无极剑圣", power=100 };
            ////魔法攻击类
            //Play play2 = new Play() { Name = "流浪法师", power = 120 };

            //Thread thread_first = new Thread(play1.physicsExecute); //物理攻击线程
            //Thread thread_second = new Thread(play2.magicExecute);  //法术攻击线程
            ////开启线程
            //thread_first.Start(monster);  //穿送怪物
            //thread_second.Start(monster);


            //第一种情况:
            //1.thread_first首先获得同步对象的锁，当执行到 Monitor.Wait(monster); 时，thread_first线程释放自己
            //  对同步对象的锁，流放自己到等待队列，直到自己再次获得锁，否则一直阻塞。
            //2.而thread_second线程一开始就竞争同步锁所以处于就绪队列中，这时候thread_second直接从就绪队列出来
            //  获得了monster对象锁，开始执行到Monitor.PulseAll(monster)时，发送了个Pulse信号。
            //3.这时候thread_first接收到信号进入到就绪状态。然后thread_second继续往下执行到 Monitor.Wait(monster, 1000)时，这是一
            //  句非常关键的代码，thread_second将自己流放到等待队列并释放自身对同步锁的独占，该等待设置了1S的超时
            //  值，当B线程在1S之内没有再次获取到锁自动添加到就绪队列。
            //4.这时thread_first从Monitor.Wait(monster)的阻塞结束，返回true。开始执行、打印。执行下一行的Monitor.Pulse(monster)，这时候
            //  thread_second假如1S的时间还没过，thread_second接收到信号，于是将自己添加到就绪队列。
            //5.thread_first的同步代码块结束以后，thread_second再次获得执行权， Monitor.Wait(m_smplQueue, 1000)返回true，
            //  于是继续从该代码处往下执行、打印。当再次执行到Monitor.Wait(monster, 1000)，又开始了步骤3。
            //6.依次循环。

            //第二种情况：thread_second首先获得同步锁对象，首先执行到Monitor.PulseAll(monster)，因为程序中没有需要等待信号进入就绪状态的线程，所以这一句代码没有意义，当执行到 Monitor.Wait(monster, 1000)，自动将自己流放到等待队列并在这里阻塞，1S 时间过后thread_second自动添加到就绪队列，线程thread_first获得monster对象锁，执行到Monitor.Wait(monster); 时发生阻塞释放同步对象锁，线程thread_second执行,执行Monitor.PulseAll(monster)时通知thread_first。于是又开始第一种情况...
            #endregion

            #region 线程池
            ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadMethod1),new object()); //参数可选
            #endregion

            Console.ReadKey();          //等待键盘输入,退出程序
        }
        public static void ThreadMethod1(object val)
        {
            for (int i = 0; i <= 100; i++)
            {

                    Console.Write(Thread.CurrentThread.Name);

            }
        }
    }
}
