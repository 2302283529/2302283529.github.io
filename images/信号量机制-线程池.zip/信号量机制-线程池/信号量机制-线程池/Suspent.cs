﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    /// <summary>
    ///   其实在C# 2.0以后， Suspent()和Resume()方法已经过时了。suspend()方法容易发生死锁。调用suspend()的时候，目标线程会停下来，但却仍然持有在这之前获得的锁定。此时，其他任何线程都不能访问锁定的资源，除非被”挂起”的线程恢复运行。对任何线程来说，如果它们想恢复目标线程，同时又试图使用任何一个锁定的资源，就会造成死锁。所以不应该使用suspend()。
    ///   只是为了了解其思路
    /// </summary>
    public class Suspent
    {
        public void Manin()
        {
            Thread threadA = new Thread(THreadMethod); //执行的必须是无返回值的方法
            threadA.Name = "小A"; //未当前的线程取一个名字
            threadA.Start(); //在此方法内传递参数，类型为object,发送和接受涉及到的拆箱操作。
            Thread.Sleep(3000); //休眠3000毫秒
            //threadA.Resume();    //继续执行已经挂起的线程
        }
        private static void THreadMethod(object parameter)//方法内可以有参数，也可以没有参数
        {
            Thread.CurrentThread.Suspend();  //挂起当前线程
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("我是:{0},我循环{1}次", Thread.CurrentThread.Name, i);                              
            }
        }
    }
}
