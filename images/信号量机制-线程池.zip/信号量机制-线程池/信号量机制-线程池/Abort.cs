﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    public class Abort
    {
        public void Manin()
        {
            Thread thread = new Thread(THreadMethod); //执行的必须是无返回值的方法
            thread.Name = "小A"; //未当前的线程取一个名字
            //thread.Start("小猪");  //在此方法内传递参数，类型为object,发送和接受涉及到的拆箱操作。
            thread.Start();//开启线程
        }
        private static void THreadMethod(object parameter)//方法内可以有参数，也可以没有参数
        {
            Console.WriteLine("我是{0},我要终止了", Thread.CurrentThread.Name);
            //开始终止线程
            Thread.CurrentThread.Abort();//　Abort()方法用来终止线程，调用此方法强制停止正在执行的线程，它会抛出一个ThreadAbortException异常从而导致目标线程的终止。
            //下面的代码不会执行
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("我是:{0},我循环{1}次",Thread.CurrentThread.Name,i);
            }
        }

    }
}
