﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    public class join
    {
        /// <summary>
        /// 　  Join方法主要是用来阻塞调用线程，直到某个线程终止或经过了指定时间为止。官方的解释比较乏味，通俗的说就是创建一个子线程，给它加了这个方法，其它线程就会暂停执行，直到这个线程执行完为止才去执行（包括主线程）。
        /// </summary>
       // public void Join();
       // public bool Join(int millisecondsTimeout);    //毫秒数
       // public bool Join(TimeSpan timeout);　　　　　　 //时间段
        public void Manin()
        {
            Thread threadA = new Thread(THreadMethod); //执行的必须是无返回值的方法
            threadA.Name = "小A"; //未当前的线程取一个名字
            threadA.Start(); //在此方法内传递参数，类型为object,发送和接受涉及到的拆箱操作。
            threadA.Join();


            Thread threadB = new Thread(THreadMethod); //执行的必须是无返回值的方法
            threadB.Name = "小B"; //未当前的线程取一个名字
            threadB.Start();//开启线程
            threadB.Join();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("我是:主线程,我循环{1}次", Thread.CurrentThread.Name, i);
                Thread.Sleep(1000);          //休眠1000毫秒                                                
            }
        }
        private static void THreadMethod(object parameter)//方法内可以有参数，也可以没有参数
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("我是:{0},我循环{1}次", Thread.CurrentThread.Name, i);
                Thread.Sleep(1000);//休眠1000毫秒                                
            }
        }
    }
}
