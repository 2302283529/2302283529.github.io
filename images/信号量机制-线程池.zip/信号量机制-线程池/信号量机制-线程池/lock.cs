﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    public class @lock
    {
        private static object obj = new object();
        private static @lock lk = new @lock();
        public void Manin()
        {
           

               Thread threadA = new Thread(lk.ThreadMethod); //执行的必须是无返回值的方法 
            threadA.Name = "A";
            Thread threadB = new Thread(lk.ThreadMethod); //执行的必须是无返回值的方法 
            threadB.Name = "B";

            //threadA.Priority = ThreadPriority.Highest;//高于主线程的优先级
            //threadB.Priority = ThreadPriority.BelowNormal;//低于主线程的优先级

            Thread.CurrentThread.Name = "C";
            lk.ThreadMethod();

            threadA.Start();
            threadB.Start();
        }
        public  void ThreadMethod()
        {
            //lock(this) 锁定，当前实例对象，如果有多个类实例的话，lock锁定的只是当前类实例，对其他类实例无影响，所有不推荐使用
            //lock(typeof(Model))锁定的是model类的实例。
            //lock(obj)锁定的对象是全局的私有化静态变量，外部无法对该变量进行访问。
            //lock 确保当一个线程位于代码的临界区时，另一个线程不进入临界区。如果其他线程试图进入锁定的代码。则它将一直等待(即被阻止)，直到该对象被释放。
            //所以，lock的结构好不好，还是关键看锁的谁，如果外边能对这个进行修改，lock就失去了作用，所以一般情况下，使用私有的，静态的并且是只读的对象。

            //lock (obj) 
            //{
            //    for (int i = 0; i < 10; i++)
            //    {
            //        Console.WriteLine("我是:{0},我循环{1}次", Thread.CurrentThread.Name, i);
            //        Thread.Sleep(300);
            //    }
            //}

            bool flag = Monitor.TryEnter(obj, 1000);//锁定对象
            //设置1S的超时时间，如果在1S之内没有获得同步锁，则返回false
            //上面的代码设置了锁定超时时间为1秒，也就是说，在1秒中后，
            //lockObj还未被解锁，TryEntry方法就会返回false，如果在1秒之内，lockObj被解锁，TryEntry返回true。我们可以使用这种方法来避免死锁
            try
            {
                //TryEnter(Object)和TryEnter() 方法在尝试获取一个对象上的显式锁方面和 Enter() 方法类似。然而，它不像Enter()方法那样会阻塞执行。如果线程成功进入关键区域那么TryEnter()方法会返回true. 和试图获取指定对象的排他锁。看下面代码演示：
                //我们可以通过Monitor.TryEnter(monster, 1000)，该方法也能够避免死锁的发生，
                if (flag)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.WriteLine("我是：{0},我被锁定了{1}次", Thread.CurrentThread.Name, i);

                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                Console.WriteLine("我是：{0},我被释放了！", Thread.CurrentThread.Name);
                if (flag)
                {
                    Monitor.Exit(obj);//释放对象
                }
            }
        }
    }
}
