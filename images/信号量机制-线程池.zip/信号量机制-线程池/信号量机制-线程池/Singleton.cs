﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 信号量机制_线程池
{
    /// <summary>
    /// 单例模式
    /// </summary>
    public class Singleton
    {
        private static Singleton instance;
        private static object obj = new object();
        //私有函数，防止实例
        private Singleton()
        {

        }
        public static Singleton GetInstance()
        {
            if (instance==null)
            {
                lock (obj) {

                    if (instance==null) {

                        instance = new Singleton();
                    }
                 }
            }
            return instance;
        }
    }
}
