﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 线程池_相关实验
{
    public class IoThread
    {
        //指出CLR线程池和IO线程池两者并没有影响。
        public void IoThreadInsert()
        {
            //托管的线程队列  //将最小线程设置为5 ,最小一步I/O线程3
            ThreadPool.SetMinThreads(5,3);

            //托管的线程队列  //将最大线程设置为5 ,最大一步I/O线程3
            ThreadPool.SetMaxThreads(5, 3);

            //初始化Studio.thordy.MaulalReStEvEnter类的新实例。
            //指示是否将初始状态设置为信号的布尔值。
            ManualResetEvent waitHandle = new ManualResetEvent(false);
            //创建一个时间计算的类
            Stopwatch watch = new Stopwatch();
            //开始计算
            watch.Start();
            //WebRequest初始化Stase.NET.WebRestQuess类的新实例。
            //为指定的URI方案初始化一个新的Stase.NET.WebRebug实例。
            WebRequest request = HttpWebRequest.Create("http://www.cnblogs.com/");
            //当在子类中重写时，开始异步请求互联网资源。
            request.BeginGetResponse(ar =>
            {
                //当在子类中重写时，返回对Internet请求的响应。
                //作为异步操作。
                var response = request.EndGetResponse(ar);
                Console.WriteLine(watch.Elapsed + ": Response Get");
            }, null);

            for (int i = 0; i < 10; i++)
            {
                //队列执行方法，并指定包含数据的对象
                ThreadPool.QueueUserWorkItem(index =>
                {
                    Console.WriteLine(String.Format("{0}: 开始 {1} 任务", watch.Elapsed, index));
                    //等待
                    waitHandle.WaitOne();

                }, i);
            }
            //等待
            waitHandle.WaitOne();
        }
    }
}
