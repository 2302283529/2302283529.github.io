﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 线程池_相关实验
{
    public class WaitCa
    {
        public static void WaitCallback(object handle)
        {
            //初始化Studio.thordy.MaulalReStEvEnter类的新实例。
            //指示是否将初始状态设置为信号的布尔值。
            ManualResetEvent waitHandle = (ManualResetEvent)handle;

            for (int i = 0; i < 10; i++)
            {
                //排队执行的方法。线程池线程执行该方法时
                // 变得可用。
                ThreadPool.QueueUserWorkItem(index =>
                {
                    //这个会报错，因为线程阻塞，这个的index是一直为空的
                    int stu = (int)index;
                    if (stu == 9)
                    {
                        //释放
                        waitHandle.Set();
                    }
                    else
                    {
                        //等待
                        waitHandle.WaitOne();
                    }
                });
            }
        }

        public void DeadLock()
        {
            //初始化Studio.thordy.MaulalReStEvEnter类的新实例。
            //布尔值，指示是否将初始状态设置为信号。
            ManualResetEvent waitHandle = new ManualResetEvent(false);
            //将最大线程设置为5
            ThreadPool.SetMaxThreads(5, 5);

            //提供可用于执行任务、后期工作项的线程池，
            //处理异步I / O，代表其他线程等待，并处理定时器。
            //WaitCallback方法，参数
            ThreadPool.QueueUserWorkItem(WaitCallback, waitHandle);

            //等待
            waitHandle.WaitOne();
        }

    }
}
