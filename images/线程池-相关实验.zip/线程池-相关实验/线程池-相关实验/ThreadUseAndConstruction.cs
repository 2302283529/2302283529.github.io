﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 线程池_相关实验
{
    public class ThreadUseAndConstruction
    {
        //创建一个无参/静态/无还回值的方法
        public  void ThreadUseAnd()
        {
            //将最小线程设置为5
            ThreadPool.SetMinThreads(5, 5);
            //将最大线程设置为12
            ThreadPool.SetMaxThreads(12, 12);
            //创建一个时间计算的类
            Stopwatch watch = new Stopwatch();
            //开始计算时间。
            watch.Start();
            //WaitCallback 委托：表示线程池线程要执行的回调方法
            WaitCallback callback = index =>
            {
                //Elapsed--获取当前实例所测量的总经过时间。
                Console.WriteLine(string.Format("{0}:任务{1}开始", watch.Elapsed, index));
                Thread.Sleep(10000);
                Console.WriteLine(string.Format("{0}:任务{1}结束", watch.Elapsed, index));
            };
            for (int i = 0; i < 20; i++)
            {
                //提供可用于执行任务、后期工作项的线程池，
                //处理异步I / O，代表其他线程等待，并处理定时器。
                ThreadPool.QueueUserWorkItem(callback, i);

                //队列执行方法，并指定包含数据的对象
                //使用该方法。当线程池线程可用时，该方法执行。
            }
            //结论：在线程池最小线程数量的范围之内，尽可能多的任务立即执行。
            //      线程池使用使用每秒不超过2个的频率创建线程（1秒一个或0.5秒一个）。
            //      当达到线程池最大线程数时（第6秒），停止创建新线程。
            //      在旧任务执行完毕后，新任务立即执行。
        }
    }
}
