﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 线程池_相关实验
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 线程池-相关实验
            ////实例化线程池的相关类
            //ThreadUseAndConstruction thread =new ThreadUseAndConstruction();
            ////调用类里面的方法
            //thread.ThreadUseAnd();
            #endregion

            #region  线程池-死锁
            //实例化线程池阻塞
            WaitCa wait = new WaitCa();
            //调用类里面的方法
            wait.DeadLock();
            #endregion

            #region 线程池-CLR线程池和一个IO线程池的对比
            //实例化线程池CLR和I/O实例
            //IoThread Lo = new IoThread();
            ////调用类里面的方法
            //Lo.IoThreadInsert();
            #endregion

            //按下键盘上的时候关闭控制台
            Console.ReadKey();
        }

    }
}
