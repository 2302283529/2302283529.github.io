﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制
{
    //1.什么是互斥，多进程环境下，若一个进程已进入临界区访问临界资源时，其他进程不得
    //进入临界区。该进程独自享有临界区全部临界资源，对于其他进程具有强烈的排斥性。这
    //种只允许一个执行流访问临界资源的情形称为互斥。
    class mythread
    {
        public Thread thrd;
        //创建一个可授权2个许可证的信号量，且初始值为2
        static Semaphore sem = new Semaphore(2,2);

        public mythread(string name)
        {
            thrd = new Thread(this.run);
            thrd.Name = name;
            //启动线程
            thrd.Start();
        }

        private void run()
        {
            //输出等待的许可证的所有进程
            Console.WriteLine(thrd.Name+"正在等待一个许可证......");
            //申请一个许可证
            sem.WaitOne();
            //输出那些申请到许可证
            Console.WriteLine(thrd.Name+"申请到许可证......");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(thrd.Name+": "+i);
                //等待1000秒钟，让所有线程进来，判断是启动和阻止信号量的线程
                Thread.Sleep(1000);
            }
            Console.WriteLine(thrd.Name+"释放许可证......");
            //释放
            sem.Release();
        }
    }
}
