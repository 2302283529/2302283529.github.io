﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制
{
    //1.什么是互斥，多进程环境下，若一个进程已进入临界区访问临界资源时，其他进程不得
    //进入临界区。该进程独自享有临界区全部临界资源，对于其他进程具有强烈的排斥性。这
    //种只允许一个执行流访问临界资源的情形称为互斥。
    public class Example
    {
        //模拟有限资源池的信号量
        private static Semaphore _pool;

        //一个填充间隔以使输出更加有序
        private static int _padding;

        /// <summary>
        /// 创建一个方法
        /// </summary>
        public  void MainIng()
        {
            //创建一个可以满足三的信号量
            //并发请求使用初始计数为零。
            //因此初始信号量计数是初始的。
            //主程序线程所属
            //目前可以发放的授权证书数量为0，授权证书总共有3个
            _pool = new Semaphore(0, 4);

            //创建并启动五个编号的线程
            for (int i = 1; i <= 10; i++)
            {
                //创建一个带输入参数的进程。
                Thread t = new Thread(new ParameterizedThreadStart(Worker));

                //启动线程，传递数字
                t.Start(i);
            }
            //等待半秒钟，让所有线程进来，判断是启动和阻止信号量的线程
            Thread.Sleep(500);
            //主线程开始保持整个线程
            //信号量计数。调用释放（3）带来
            //信号量计数返回其最大值，以及
            //允许等待线程进入信号量,
            //每次高达三个.
            Console.WriteLine("主线程调用释放(4)。");
            //释放信号量
            _pool.Release(4);//归还了授权证书后，其他等待的线程才可以获得授权证书并且运行

            Console.WriteLine("主线程退出。");

            Console.Read();
        }

        /// <summary>
        /// 创建一个无返回执的方法
        /// </summary>
        /// <param name="num"></param>
        public static void Worker(object num)
        {
            //每个工作线程都是通过请求
            //信号量计数
            Console.WriteLine("线程{0}开始" + "并等待信号量。", num);
            //等待信息量
            _pool.WaitOne();
            //一个填充间隔以使输出更加有序。
            //Interlocked.Increment　　　　原子操作，递增指定变量的值并存储结果。
            //Interlocked.Decrement 原子操作，递减指定变量的值并存储结果。
            //Interlocked.Add 原子操作，添加两个整数并用两者的和替换第一个整数
            //Interlocked.CompareExchange(ref a, b, c); 原子操作，a参数和c参数比较，  相等b替换a，不相等不替换。
            //原子操作:所谓原子操作是指不会被线程调度机制打断的操作；这种操作一旦开始，就一直运行到结束，中间不会有任何 context switch （切[1]  换到另一个线程）。
            int padding = Interlocked.Add(ref _padding, 100);//加锁

            Console.WriteLine("线程{0}进入信号量。", num);
            //线程的工作，大概每一秒执行一点点，为了一点点获取更长，只是为了使产出更有序。
            Thread.Sleep(1000 + padding);

            Console.WriteLine("线程{0}释放信号量。", num);
            Console.WriteLine("线程{0}先前信号量计数：{1}", num, _pool.Release());
            Console.WriteLine("线程{0}完成", num);
        }

        //运行过程:1.信号量被初始化为(1,3),此时，信号量中可以发出的授权证书数目为1
        //         2.Thread1获取授权证书。后，信号量可以发出的授权证书数目为0，而此时，Thread2/3/4/5都处于等待状态
        //         3.Main函数使用Release(3),归还给信号量3个授权证书。此时信号量可以发放的授权证数目是3。
        //         4.Thread2/3/4获取授权证书，后，信号量可以发出的授权证书数目是0，此时Thread6继续处于等待状态
        //         5.Thread1运行完毕，归还一个授权证，此时信号量可发放授权证书是1
        //         6.Thread5获取授权证书。后，信号量可以发出的授权证书数目是0
        //         7.Thread2/3/4运行完毕，分别归还授权证书，此时信号量可发放证书数目是3，已经达到了初始化时，规定的最大数量
        //         8.Thread5运行完毕，归还授权证书，此时信号量可发放证书数目再次加一次时，便超出了规定最大数目，出现了Exception.
    }
}
