﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 信号量机制
{
    class Program
    {
        //1.什么是互斥，多进程环境下，若一个进程已进入临界区访问临界资源时，其他进程不得
        //进入临界区。该进程独自享有临界区全部临界资源，对于其他进程具有强烈的排斥性。这
        //种只允许一个执行流访问临界资源的情形称为互斥。
        static void Main(string[] args)
        {
            #region 案例一
            //Example Repulsion = new Example();
            //Repulsion.MainIng();
            #endregion

            #region 案例二
            mythread mythread1 = new mythread("线程一");
            mythread mythread2 = new mythread("线程二");
            mythread mythread3 = new mythread("线程三");
            mythread mythread4 = new mythread("线程四");
            mythread1.thrd.Join();
            mythread2.thrd.Join();
            mythread3.thrd.Join();
            mythread4.thrd.Join();
            #endregion
            Console.Read();
        }

    }
}
